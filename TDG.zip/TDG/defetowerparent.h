#ifndef DEFETOWERPARENT_H
#define DEFETOWERPARENT_H

#include <QString>
#include "monster.h"

//防御塔父类
class DefeTowerParent
{
//防御塔属性
protected:
    int mx, my;
    int width, height;
    QString BaseImgPath;
    QString DefImgPath;
    int RotatAngle = 0;
    int UpLeftX, UpLeftY;
    int Range;

    Monster* aimsmon = NULL;

    QString BullPath;
    int power;
    int bullwidth, bullheight;
    QVector<BulletStr*> BulletVec;
    int counter = 0;
    int attack;
public:
    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
    int GetRotatAngle() const;
    QString GetBaseImgPath() const;
    QString GetDefImgPath() const;
    int GetUpLeftX() const;
    int GetUpLeftY() const;
    void SetRotatAngle(int rot);
    int GetRange() const;

    Monster* GetAimsMonster() const;
    void SetAimsMonster(Monster*);

    QString GetBulletPath() const;
    QVector<BulletStr*>& GetBulletVec();
    void InterBullet();
    void BulletMove();
    int GetBulletWidth() const;
    int GetBulletHeight() const;
    int GetAttack() const;
    //升级
    void SetAttack(int);
    void SetWidthHeight(int, int);
    void SetXY(int, int);
    int& SetRange();

    void SetBulletWidthHeight(int, int);
};

#endif // DEFETOWERPARENT_H
