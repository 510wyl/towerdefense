#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "defensetowerpit.h"
#include "selectionbox.h"
#include "defetowerparent.h"
#include "monster.h"
#include <QLabel>

class MainWindow : public QWidget
{
//    Q_OBJECT
private:
    QVector<DefenseTowerPit*> TowerPitVec;
    SelectionBox* SelBox = new SelectionBox(":/image/SelectionBox.png");

    QVector<DefeTowerParent*> DefeTowerVec;

    QVector<Monster*> MonsterVec;

    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
//    void mouseMoveEvent(QMouseEvent *);

    void DrawMapArr(QPainter&);
    void DrawSelectionBox(QPainter&);
    void DrawDefenseTower(QPainter&);
    void DrawMonster(QPainter&);
    void DrawRangeAndUpgrade(QPainter&);

    int DisplayRangeX, DisplayRangeY;
    bool DisplayRange = false;

    int money = 1000;
    QLabel *moneylable = new QLabel(this);

    inline bool DeductionMoney(int);

    int life = 10;

    int counter = 0;

    const int RewardMoney = 28;

    CoorStr *homecoor = new CoorStr(0, 0);

    void IrodMonsProgDefa(CoorStr**, CoorStr**, CoorStr*, int*, QLabel*);

    const int LevelNumber;

    bool DisplayAllRange = false;
public:
    MainWindow(int);
    ~MainWindow();
};

#endif  //MAINWINDOW_H
