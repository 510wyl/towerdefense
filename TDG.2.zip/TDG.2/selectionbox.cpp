#include "selectionbox.h"

SelectionBox::SelectionBox(QString Path, int width, int height) :
    mwidth(width), mheight(height), SelecBoxImgPath(Path) {}

int SelectionBox::GetX() const
{
    return mx;
}
int SelectionBox::GetY() const
{
    return my;
}
int SelectionBox::GetWidth() const
{
    return mwidth;
}
int SelectionBox::GetHeight() const
{
    return mheight;
}

QString SelectionBox::GetImgPath() const
{
    return SelecBoxImgPath;
}

bool SelectionBox::GetDisplay() const
{
    return display;
}

void SelectionBox::SetDisplay(const bool SetPlay)
{
    display = SetPlay;
}

void SelectionBox::CheckTower(int x, int y)
{
    mx = x - 95, my = y - 95;

    SubBut[3].SubX = mx + 106, SubBut[3].SubY = my + 190;
    SubBut[3].SubImgPath = QString(":/image/cannon.png");

    display = true;
}

SubbutStr* SelectionBox::GetSelSubBut()
{
    return SubBut;
}
