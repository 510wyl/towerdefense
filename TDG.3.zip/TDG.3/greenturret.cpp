#include "greenturret.h"

//绿色防御塔类
GreenTurret::GreenTurret(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{
    mx = x, my = y;
    BaseImgPath = QString(":/image/GreenBottleBase.png");
    DefImgPath = QString(":/image/GreenBottle.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 200;

    BullPath = QString(":/image/Shells0.png");
    bullwidth = 30, bullheight = 30;

    attack = 40;

    ExplRangeWidth = 65;
    ExplRangeHeight = ExplRangeWidth;
}
