#include "lightturret.h"

//光炮防御塔类
LightTurret::LightTurret(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{
    mx = x, my = y;
    BaseImgPath = QString(":/image/GreenBottleBase.png");
    DefImgPath = QString(":/image/BrightCannon.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 260;

    BullPath = QString(":/image/Shells2.png");
    bullwidth = 40, bullheight = 40;

    attack = 94;

    ExplRangeWidth = 75;
    ExplRangeHeight = ExplRangeWidth;
}
