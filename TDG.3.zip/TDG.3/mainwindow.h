#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "defensetowerpit.h"
#include "selectionbox.h"
#include "defetowerparent.h"
#include "monster.h"
#include <QLabel>

class MainWindow : public QWidget
{
private:
    QVector<DefenseTowerPit*> TowerPitVec;  //防御塔坑数组
    SelectionBox* SelBox = new SelectionBox(":/image/SelectionBox.png");
    QVector<DefeTowerParent*> DefeTowerVec;

    QVector<Monster*> MonsterVec;           //怪物数组

    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);

    void DrawMapArr(QPainter&);
    void DrawSelectionBox(QPainter&);
    void DrawDefenseTower(QPainter&);
    void DrawMonster(QPainter&);
    void DrawRangeAndUpgrade(QPainter&);
    void DrawExplosion(QPainter&);

    int DisplayRangeX, DisplayRangeY;
    bool DisplayRange = false;

    struct ExploStr     //爆炸效果结构
    {
        CoorStr coor;
        int index = 1;

        int ExplRangeWidth;
        int ExplRangeHeight;
        ExploStr(CoorStr fcoor, int width, int height) : coor(fcoor), ExplRangeWidth(width), ExplRangeHeight(height) {}
    };

    QVector<ExploStr*> ExploEffectCoor;      //爆炸效果坐标数组

    int money = 1000;
    QLabel *moneylable = new QLabel(this);

    inline bool DeductionMoney(int);

    int life = 10;

    int counter = 0;

    const int RewardMoney = 28;

    CoorStr *homecoor = new CoorStr(0, 0);

    void IrodMonsProgDefa(CoorStr**, CoorStr**, CoorStr*, int*, QLabel*);

    const int LevelNumber;

    bool DisplayAllRange = false;
public:
    MainWindow(int);
    ~MainWindow();
};

#endif  //MAINWINDOW_H
