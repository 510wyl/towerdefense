#include "monster.h"
#include <QDebug>

//怪物类
Monster::Monster(CoorStr **pointarr, int arrlength, int x, int y, int fid) :
    mx(x), my(y), id(fid)
{
    for(int i = 0; i < arrlength; i++)
        Waypoint.push_back(pointarr[i]);

    switch (id)
    {
    case 1: //小恐龙怪1
        health = 100;
        mwidth = 64, mheight = 64;
        ImgPath = ":/image/monster1.png";
        break;
    case 2: //鱼怪2
        health = 120;
        mwidth = 86, mheight = 64;
        ImgPath = ":/image/monster2.png";
        break;
    case 3: //飞龙怪3
        health = 650;
        mwidth = 160, mheight = 120;
        ImgPath = ":/image/monster3.png";
        break;
    case 4: //狮子怪4
        health = 310;
        mwidth = 98, mheight = 70;
        ImgPath = ":/image/monster4.png";
        break;
    case 5: //蜗牛怪5
        health = 200;
        mwidth = 90, mheight = 76;
        ImgPath = ":/image/monster5.png";
        break;
    default:
        break;
    }
}

//怪物按设定路径点移动
bool Monster::Move()
{
    if(Waypoint.empty())
        return true;

    if (Waypoint.at(0)->y > my) //下
    {
        my += mspeed;
        return false;
    }

    if (Waypoint.at(0)->x < mx) //左
    {
        mx -= mspeed;
        return false;
    }

    if (Waypoint.at(0)->x > mx) //右
    {
        mx += mspeed;
        return false;
    }

    if (Waypoint.at(0)->y < my) //上
    {
        my -= mspeed;
        return false;
    }

    if (Waypoint.at(0)->y == my && Waypoint.at(0)->x == mx)
    {
//        delete Waypoint.begin();
        Waypoint.erase(Waypoint.begin());

//        return false;
    }

    return false;
}


int Monster::GetX() const
{
    return mx;
}

int Monster::GetY() const
{
    return my;
}

int Monster::GetWidth() const
{
    return mwidth;
}

int Monster::GetHeight() const
{
    return mheight;
}

QString Monster::GetImgPath() const
{
    return ImgPath;
}

int Monster::GetId() const
{
    return id;
}

int Monster::GetHealth() const
{
    return health;
}

void Monster::SetHealth(int fhealth)
{
    health = fhealth;
}
